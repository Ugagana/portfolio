const navLinks = [
    {
        id: 1,
        link: "Home"
    },
    {
        id: 2,
        link: "About"
    },
    {
        id: 3,
        link: "Projects"
    },
    {
        id: 4,
        link: "Skills"
    },
    // {
    //     id: 5,
    //     href:"",
    //     link: "Blog"
    // },
    {
        id: 6,
        link: "Contact"
    }
];

export default navLinks;